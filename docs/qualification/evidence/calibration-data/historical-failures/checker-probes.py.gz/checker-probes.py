import json, hashlib, shutil, sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch
ROOT=Path('/Users/henrique/.codex/worktrees/v1-r3-qualification/magicite')
sys.path.insert(0,str(ROOT/'src'))
from magicite.eval import data_readiness as d
BASE=Path('/private/tmp/magicite-v1-calibration/checker-cases'); BASE.mkdir(exist_ok=True)
results=[]
def case(name):
 p=BASE/name
 if p.exists(): shutil.rmtree(p)
 shutil.copytree(ROOT/'tests/fixtures/calibration-data',p)
 return p

def load(p):return json.loads(p.read_bytes())
def save(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
def change(p,section,name,fn):
 packet=load(p/'packet.json');ref=packet[section][name];target=p/ref['path'];x=load(target);fn(x);save(target,x);ref['sha256']=hashlib.sha256(target.read_bytes()).hexdigest();save(p/'packet.json',packet)
def outcome(p):
 try:return {'accepted':True,'report':d.prepare_packet(p/'packet.json').report}
 except Exception as e:return {'accepted':False,'error':type(e).__name__+': '+str(e)}
for run in range(2):
 p=case('hidden-known-group-'+str(run))
 change(p,'evidence','source1',lambda x:x['group_keys'].update(repository='fixture-repository0'))
 change(p,'files','provenance',lambda x:x[1]['source'].update(group_keys=None,unavailable_reason='declared unknown'))
 before=outcome(p)
 change(p,'files','provenance',lambda x:x[1]['source'].update(group_keys=load(p/'source1.json')['group_keys']))
 after=outcome(p)
 results.append({'case':'known group in bound evidence hidden by unavailable declaration','run':run,'hidden':before,'restored':after})
# All three family pairs, unicode equivalent strings, retain byte-valid references.
for i,j in [(0,1),(0,2),(1,2)]:
 p=case(f'normalized-{i}-{j}')
 change(p,'files','runtime',lambda x:x[j].update(query_text=' '+x[i]['query_text'].upper()+'  '))
 results.append({'case':f'normalized pair {i}/{j}',**outcome(p)})
# Durable failure at link and directory fsync separately, intercept JSON decoder independently.
for mode in ['link-failure','directory-fsync','race']:
 p=case(mode); f=p/'freeze.json'
 d.freeze_packet(p/'packet.json',f,source_commit='1'*40,runner_sha256='2'*64)
 labels_bytes=(p/'labels.json').read_bytes();calls=[]; orig=json.loads
 def decode(raw,*a,**kw):
  if raw==labels_bytes:
   calls.append(d.access_path(f).exists())
  return orig(raw,*a,**kw)
 with patch.object(json,'loads',decode):
  if mode=='race':
   def op(n):
    try: d.open_final_labels(f,purpose='checker');return 'released'
    except FileExistsError:return 'denied'
   with ThreadPoolExecutor(max_workers=2) as pool: result=list(pool.map(op,range(2)))
  else:
   target='link' if mode=='link-failure' else 'fsync'
   original=getattr(d.os,target); n=[0]
   def fail(*args,**kw):
    n[0]+=1
    if target=='link' or n[0]==2: raise OSError('checker injected persistence failure')
    return original(*args,**kw)
   with patch.object(d.os,target,fail):
    try:d.open_final_labels(f,purpose='checker');result='RELEASED UNEXPECTED'
    except OSError as e:result=str(e)
 results.append({'case':mode,'result':result,'semantic_labels_receipt_exists':calls,'receipt_exists':d.access_path(f).exists()})
(Path('/private/tmp/magicite-v1-calibration/checker-probes-results.json')).write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
