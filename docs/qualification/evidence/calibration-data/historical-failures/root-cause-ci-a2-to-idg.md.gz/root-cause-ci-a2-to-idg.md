---
eidolon: vigil
version: 1.8.0
kind: root-cause-report
status: latest-ci-failed-test-contract-pending-repair
created_at: '2026-10-08T12:18:48.828649+00:00'
thread_id: 59f3b808-f1e0-43c3-baed-a40b525be9e8
reproduction_runs: 2
hypotheses_count: 3
interventions_count: 4
blame_target: 'tests/unit/test_docs_v1.py:46-83'
non_determinism_declared: false
evidence_anchors_count: 4
---
# Immutable VIGIL addendum: archive A2 full-suite failure

Archive A2 16d66bb906eddb0c4192d0905a02dc572daf99db is the current failed head. Final all-ten status is NOT_MET. This adds to the prior root-cause-verification-to-idg report without rewriting its archive-A lint attribution: the gzip representation repair passed lint, then the full suite revealed a separate stale test expectation. Measured source C5167757c5b5e661096cf86bacab670e90f44980e and prior archive A d314f89311d90806bd9c5c7de4f6a3a48c46db1b retain their historical identities.

## reproduction

Actual run37773569708 jobs113298790635/Python3.11 and113298790523/Python3.12 each fail test_readme_claim_uses_full_integrity_chain[None] at tests/unit/test_docs_v1.py:83. Both report1failed/2017passed/12skipped/1deselected in the full-suite coverage step. Coverage70% gate is met:87.27% and87.26% respectively. This is not a coverage failure or a later acceptance-only failure. Actual failed logs are ci-job-113298790635-failed.log and ci-job-113298790523-failed.log. Two scoped local runs of that exact parameter reproduce the same missing final packet/access-binding rejection (checker-ci-a2-reproduction-1.log and-2.log); source stays clean at A2.

## hypotheses

H1 the old positive fixture expectation incorrectly treats a boolean-sealed synthetic final claim as accepted under the strengthened contract. H2 corpus/result/prediction digest-chain mismatch is the actual failure. H3 hosted environment/version drift is required. Source reading follows _bundle's _seal call and supported/final claim into docs_v1_contracts.check_readme_claims → check_v1_claim_bundle → validate_claim_integrity → validate_experiment_corpus_seal. The rejection is the intended bare-final seal guard. Local replay falsifies the hosted-only explanation.

## interventions

I-4 is a test-input-only counterfactual under /private/tmp/magicite-v1-calibration, not a repository edit. It selects only the existing development query from the imported tiny fixture, preserving original split labels, recomputes the canonical corpus identity, and binds the claim/README population to development. All six original integrity-chain cases (positive plus value/metric/scope/missing_predictions/historical mutations) pass in0.38s with unchanged production validators. Retained temporary test: test_docs_development_counterfactual.py; output checker-ci-a2-counterfactual.log. This isolates the stale final-positive expectation and confirms the remaining digest chain works. Four intervention classes total across this mission, within the five cap.

## blame_target

[FINDING-004] H [ROOT-CAUSE] — tests/unit/test_docs_v1.py:46-83 retains an old positive expectation for a supported final claim whose experiment is only boolean-sealed. Frozen AC-CD-08 now requires that claim to fail. The product guard at src/magicite/eval/validate.py:173-193 and claim caller:503-510 is behaving as specified. Correct repair is scoped test adaptation: a development-only positive binding fixture, preserving negative integrity mutations, plus explicit bare-final rejection coverage. Do not weaken the product guard, grant a fixture exemption to empirical claims, or make every mutation trivially fail from an unrelated seal error. tests/unit/test_docs_v1.py is outside original owned paths; root must authorize prospective narrow scope before maker source writes.

## chronicle_hooks

Record A2's exact failed CI independently from A's previous lint failure. Prior gzip counterfactual and repository lint pass remain valid. Root should preserve the exact failed-head receipt, authorize only the evidenced test change after scope clarification, and require subsequent final-head checks before all-ten acceptance. No production model/calibration fitting call was made in this diagnosis; scoped tests use existing diagnostic fixture predictions, not empirical observations. No source files were changed by VIGIL. Authentic data/no-match/group/temporal/fresh-final/E2/E3/E6 remain UNEVALUATED; native/Gauge/human acceptance is not asserted. Use the installed VIGIL→IDG INFORM root-cause-report edge and a fresh actual root receiver verification; no earlier pending or failed receipt is relabeled passing.
