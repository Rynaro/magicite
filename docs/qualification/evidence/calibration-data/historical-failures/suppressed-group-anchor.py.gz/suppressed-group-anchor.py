"""Independent finding anchored against frozen AC-CD-01/03; fail if suppression accepted."""
import hashlib,json,shutil,sys,tempfile
from pathlib import Path
sys.path.insert(0,'/Users/henrique/.codex/worktrees/v1-r3-qualification/magicite/src')
from magicite.eval import data_readiness as d
fixture=Path('/Users/henrique/.codex/worktrees/v1-r3-qualification/magicite/tests/fixtures/calibration-data')
with tempfile.TemporaryDirectory(prefix='suppressed-group-',dir='/private/tmp/magicite-v1-calibration') as work:
 root=Path(work);shutil.copytree(fixture,root/'inputs');root=root/'inputs'
 packet=json.loads((root/'packet.json').read_bytes())
 source=json.loads((root/'source1.json').read_bytes());source['group_keys']['repository']='fixture-repository0'
 (root/'source1.json').write_text(json.dumps(source,sort_keys=True))
 packet['evidence']['source1']['sha256']=hashlib.sha256((root/'source1.json').read_bytes()).hexdigest()
 prov=json.loads((root/'provenance.json').read_bytes());prov[1]['source'].update(group_keys=None,unavailable_reason='declared unknown')
 (root/'provenance.json').write_text(json.dumps(prov,sort_keys=True))
 packet['files']['provenance']['sha256']=hashlib.sha256((root/'provenance.json').read_bytes()).hexdigest()
 (root/'packet.json').write_text(json.dumps(packet,sort_keys=True))
 try:d.prepare_packet(root/'packet.json')
 except ValueError as exc:print('PASS suppressed bound known group rejected:',exc)
 else:raise AssertionError('AC-CD-01/03: known referenced repository group was hidden by unavailable declaration')
